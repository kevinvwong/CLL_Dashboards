## Context

The app is server-rendered, at `127.0.0.1:8000`. Its JSON error bodies suggest FastAPI. Interactions are partial-page swaps, likely htmx. The Outcomes page (`/oct16`) is the most finished screen and becomes the visual reference. Users are the Dean (Bill), team leads (Elizabeth, Mario, Tim), and the Associate Director, Strategic Operations (Kevin). The weekly meeting and posting updates are the core loops.

## Goals / Non-Goals

- Goals:
  - One visual language.
  - Every entity reachable from the nav and from search.
  - Fast update entry.
  - A meeting view that runs the meeting.
  - Usable at the side-panel width (~726px) and on mobile.
- Non-Goals:
  - Changing the data model or permissions model.
  - KPI computation.
  - Authentication. Switch user stays a prototype affordance.

## Decisions

- **The Outcomes page is the design source.** Its pill, card, and progress-bar styles are extracted into tokens and components, so no new style is introduced.
- **Partial vs. full responses.** Any endpoint that serves both a modal or drawer and a full page checks for a partial request header, such as `HX-Request` / `HX-Target`. It returns a fragment for partial requests and the full layout otherwise. This fixes the nested layout bug and the duplicate close control.
- **Drawer over modal for initiative detail.** The user keeps the list context. The URL updates (`/initiatives/{id}`) so the view can be shared. Loading that URL directly renders a full page.
- **Filter state in the query string.** Views can be shared and bookmarked. No client-side store is needed.
- **Status scale is fixed and always labeled:**

  | Status | Color |
  |---|---|
  | On track | green |
  | At risk | amber |
  | Off track | red |
  | Not started | grey |
  | Done | blue |

  Color is never the only signal.
- **Stale threshold** defaults to 14 days and is configurable in one place.
- **"Last meeting date"** is the most recent meeting date stored or configured. If none exists, it falls back to 7 days ago.

## Risks / Trade-offs

- Restyling every template at once risks regressions. Mitigation: ship the tokens and components first (task group 2), then migrate one page at a time.
- Presenter mode adds a second layout to maintain. Mitigation: it reuses the meeting fragments with a larger-type modifier class.
- The search index is built per request from the database. This is acceptable at the current size (<100 initiatives). Revisit it above roughly 1,000.

## Migration Plan

1. Ship the bug fixes behind no flag.
2. Add new routes. Make `/oct16` return a 301 redirect to `/outcomes`.
3. Migrate templates page by page to the shared components.
4. Remove the legacy styles once no template references them.

## Open Questions

- Which roles may edit owner, goals and priorities, and tier? Only the owner and admins, or anyone?
- Is there a canonical "meeting date" record, or should the app store one each time a meeting is run?
- Should the sample-data banner be dismissible per session or per user?
