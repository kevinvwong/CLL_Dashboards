## 1. Bug fixes

- [ ] 1.1 Edit details endpoint returns only the form fragment for partial requests and the full layout otherwise
- [ ] 1.2 Standalone initiative page omits the modal close control and shows a breadcrumb instead of "← Back"
- [ ] 1.3 Goal and priority pages render each group header before its group, with no orphan tier labels
- [ ] 1.4 Replace "On track N" rollups with the total count plus a per-status breakdown
- [ ] 1.5 Pluralize day counts correctly ("1 day", "N days")
- [ ] 1.6 Add a GET handler for `/initiatives` and a route for `/people`, and add a styled 404 page for unknown routes
- [ ] 1.7 Give the goal and priority card links accessible names

## 2. Design system foundation

- [ ] 2.1 Extract CSS tokens (color, spacing, radius, type scale, shadows) from the Outcomes page, with dark-mode overrides
- [ ] 2.2 Build shared components:
  - status pill
  - progress bar
  - initiative row
  - stat tile
  - card
  - chip
  - button variants
  - form field
  - drawer
  - modal
  - toast
  - empty state
  - breadcrumb
- [ ] 2.3 Replace the two-layer sample-data banner with one thin, dismissible bar
- [ ] 2.4 Define the responsive breakpoints (≤640, ≤1024, >1024) and the collapsing nav
- [ ] 2.5 Add focus-ring styles, drawer and modal focus trapping, Esc to close, and focus return

## 3. Navigation

- [ ] 3.1 New primary nav (Overview, Initiatives, People, Meeting, Outcomes), with the active state
- [ ] 3.2 Add the `/outcomes` route and a 301 redirect from `/oct16`
- [ ] 3.3 Add a user menu containing the current user and Switch user
- [ ] 3.4 Move Data checks to an admin-only entry that shows the count of failing checks
- [ ] 3.5 Global search (⌘K / Ctrl+K) across initiatives, people, goals, and priorities
- [ ] 3.6 Breadcrumbs on every page below the top level

## 4. Portfolio views

- [ ] 4.1 Overview: portfolio health strip, status breakdown bars on the goal and priority cards, and descriptions on the priority cards
- [ ] 4.2 Initiatives index: filterable and sortable table, with filters kept in the query string
- [ ] 4.3 People index and person page: status breakdown, stale-update flag, sorted by attention
- [ ] 4.4 Goal and priority pages: header pattern, a group-by toggle (owner, tier, status), and each row as a single click target

## 5. Initiative detail and editing

- [ ] 5.1 Initiative detail in a right-side drawer that updates the URL. Loading the URL directly renders the full page
- [ ] 5.2 Detail layout:
  - header with status, progress, owner, and actions
  - facts block
  - Latest update callout
  - diary timeline
  - fed-by and feeds lists with status and progress
- [ ] 5.3 Update form:
  - labels above fields
  - segmented status control
  - progress slider paired with a number input
  - the previous value
  - character counter
  - primary Save button
- [ ] 5.4 Inline save: the row updates in place and a toast confirms, with no full reload
- [ ] 5.5 Edit details covers owner, goals and priorities (with the primary flag), tier, and the parent D-1 link, gated by role

## 6. Meeting review

- [ ] 6.1 "Since" defaults to the last meeting date, with quick ranges (Last meeting, 7d, 14d)
- [ ] 6.2 Agenda sections: Needs attention, Changes since, No update since
- [ ] 6.3 Show the change in progress and status between updates (e.g. "30% → 45%")
- [ ] 6.4 Presenter mode (large type, one owner at a time, arrow-key navigation)
- [ ] 6.5 Print stylesheet and print view

## 7. Admin checks

- [ ] 7.1 List each check rule with pass/fail status
- [ ] 7.2 Each failure links to the initiative or edit form that resolves it

## 8. Verification

- [ ] 8.1 Visual check of every page at 375, 726, and 1280px, in light and dark modes
- [ ] 8.2 Keyboard-only pass: nav, search, drawer, update form, presenter mode
- [ ] 8.3 Contrast check (WCAG AA) on all text and status pills
- [ ] 8.4 Regression: saving updates, editing details, switching users, and following the `/oct16` redirect all work
