# Change: Overhaul UI/UX, navigation, and design system

## Why

The Initiative Dashboard has two visual languages. The Outcomes page (`/oct16`) uses cards, status pills, progress bars, and milestone rows. Every other page uses plain lists, browser-default buttons, and unstyled forms. Several defects come from this split:

- Edit details loads the full site layout inside the modal.
- The standalone initiative page shows both "← Back" and the modal's "×".
- On goal and priority pages, group headers render in the wrong order.

Navigation has gaps:

- There are no index pages for initiatives or people. `/initiatives` returns 405 JSON and `/people` returns 404 JSON.
- There is no search and there are no breadcrumbs.
- One primary nav item is tied to a date (`/oct16`).
- An admin tool (Checks) sits in the main nav.

The two highest-traffic workflows, posting an update and running the weekly meeting, have the least design attention.

## What Changes

- **Bug fixes:**
  - The Edit details modal shows only the edit form.
  - The standalone initiative page drops the modal close control.
  - Group headers render before their groups.
  - The rollup labels on goal and priority pages are corrected.
  - "1 days" becomes "1 day".
  - A styled 404 page replaces raw JSON errors.
- **Navigation:**
  - New primary nav: Overview, Initiatives, People, Meeting, Outcomes.
  - New `/initiatives` and `/people` index pages.
  - `/outcomes` replaces `/oct16`, which redirects to it.
  - Global search (⌘K / Ctrl+K).
  - Breadcrumbs on every page below the top level.
  - A user menu that holds Switch user.
  - Data checks moves to an admin-only entry that shows the count of failing checks.
- **Design system:**
  - Design tokens and shared components taken from the Outcomes page, including a single status color scale.
  - Responsive breakpoints, dark mode, and an accessibility baseline.
  - A slimmer sample-data banner.
- **Portfolio views:**
  - The Overview gets a portfolio health strip, and its goal and priority cards get status breakdowns.
  - Goal and priority pages get a grouping toggle, with each initiative row as a single click target.
  - People pages flag stale updates.
- **Initiative detail:**
  - Detail opens in a right-side drawer over the list.
  - New Update form: segmented status control, a progress slider paired with a number input, the previous value, a character counter, and an inline save with a toast.
  - Edit details covers owner, goals and priorities, tier, and the parent D-1 link.
- **Meeting review:**
  - Guided agenda in three parts: needs attention, changes since the last meeting, and initiatives with no update.
  - Each change shows the before and after values (deltas).
  - Quick date ranges.
  - Presenter mode and a print view.
- **Admin checks:** the checks page lists each rule with pass/fail and links to fix each failure.

No breaking changes to data. `/oct16` remains reachable through a redirect.

## Impact

- Affected specs (all new; no specs exist yet):
  - `app-navigation`
  - `design-system`
  - `portfolio-views`
  - `initiative-detail`
  - `meeting-review`
  - `admin-checks`
- Affected code:
  - base layout template
  - all page templates
  - the initiative modal and its partial endpoints
  - the update and edit handlers
  - the meeting query (adds "no update since")
  - new routes: `/initiatives` (GET), `/people`, `/outcomes`, `/search`
  - the shared stylesheet
